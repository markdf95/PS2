using System.Linq;
using Xunit;
using Xunit.Abstractions;
using Microsoft.EntityFrameworkCore;
using PS2.Models;
using System;
using PS2.Controllers;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace PS2UnitTest
    {
    public class PS2UnitTsts
        {
        private const string strEmpty = "";
        private const string alpha = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz";
        private int nAlphaLen = alpha.Length;
        private string[] strFName = { "William", "Bill", "Mary", "Joan", "Melissa" };
        private string[] strLast = { "Jones", "Smith", "Smyth", "Abercrombie", "O'Reilly" };
        private string[] strAddr = { "223 E 490 W", "19 First Ave", "918 Brackenridge Ave", "44 Morgan St", "1004 Freeport Rd" };
        private int[] nAge = { 3, 44, 2, 66, 4 };
        private string[] strCity = { "Freeport", "Lower Burrell", "Bountiful", "Huntington", "Las Vegas" };
        private string[] strState = { "PA", "UT", "WV", "CO", "WA" };
        private string[] strInterests = { "Bicycling", "Hiking", "Surfing", "Boating", "Hunting" };
        private int[] nZip = { 39393, 22355, 29222, 12990, 83922 };
        //ADDED TO CAPUTRE XUNIT OUTPUT - CAN'T USE CONSOLE.WRITELINE
        private readonly ITestOutputHelper output;

        public PS2UnitTsts(ITestOutputHelper output)
            {
            this.output = output;
            InitContext();
            }
        private PS2Context _ctext;

        [Fact]
        public void InitContext()
            {
            try
                {
                //BUILD CONTEXT OPTIONS NEEDED TO CREATE DB CONTEXT FOR TESTING
                var builder = new DbContextOptionsBuilder<PS2Context>().UseInMemoryDatabase("Persons");
                //CREATE TEST CONTEXT
                var context = new PS2Context(builder.Options);
                //IF WE HAVE RECORDS, NOT NEED TO RE-SEED
                if (context.Persons.Count() == 0)
                    {
                    //SEED THE IN MEMORY DB
                    Random rndm = new Random(DateTime.Now.Millisecond);
                    output.WriteLine("Seeding Persons DB with:");
                    //THIS COULD PRODUCE DUPLICATE NAMES
                    for (int i = 0; i < 5; i++)
                        {
                        var p = new Person
                            {
                            FirstName = strFName[rndm.Next() % 5],
                            LastName = strLast[rndm.Next() % 5],
                            Age = nAge[rndm.Next() % 5],
                            City = strCity[rndm.Next() % 5],
                            StreetAddress = strAddr[rndm.Next() % 5],
                            Interests = strAddr[rndm.Next() % 5],
                            PicName = "favicon.ico",
                            State = strState[rndm.Next() % 5],
                            Zip = nZip[rndm.Next() % 5]
                            };
                        context.Add(p);
                        output.WriteLine(p.FirstName + " " + p.LastName);
                        }
                    //COUNT IS RETURNED
                    int changed = context.SaveChanges();
                    }

                _ctext = context;
                }
            catch (Exception ex)
                {
                throw new Exception(ex.Message);
                }
            }
        [Fact]
        public void TestGetAllMixedCase()
            {
            var controller = new PersonController(_ctext);
            IEnumerable<Person> result = controller.Get("aLL");
            Assert.Equal(5, result.Count());
            }
        [Fact]
        public void TestGetAllNull()
            {
            var controller = new PersonController(_ctext);
            IEnumerable<Person> result = controller.Get(null);
            Assert.Equal(5, result.Count());
            }
        //TODO FINISH THIS
        //[Fact]
        //public void TestPostPersonNoPic()
        //    {
        //    ImgUpload controller = new ImgUpload( _ctext);
        //    Person p = new Person
        //        {
        //        FirstName = "Bill",
        //        LastName = "Bowers",
        //        Age = 22,
        //        City = "Smallville",
        //        StreetAddress = "33 W 220 N",
        //        Interests = "Archery",
        //        PicName = "None",
        //        State = "WY",
        //        Zip = 33993
        //        };
        //    HttpRequest rq = new HttpRequest;
        //    rq.ContentType = "applicatoin/json";

        //    IEnumerable<Person> result = controller.UploadJsonFile(p);
        //    Assert.Equal(5, result.Count());
        //    }
        [Fact]
        public void TestGetEmptyStr()
            {
            var controller = new PersonController(_ctext);
            IEnumerable<Person> result = controller.Get("");
            Assert.Equal(5, result.Count());
            }
        [Fact]
        public void TestGetMatch()
            {
            var controller = new PersonController(_ctext);
            //PICK RANDOM CHARS TO MATCH
            Random rndm = new Random(DateTime.Now.Millisecond);
            StringBuilder sb = new StringBuilder();
            int nFound = 0;
            
            //FIND 5 MATCHES
            while (nFound < 5)
                {
                //RANDOMLY SELECT LENGTH OF SEARCH STRING - 2 TO 5 CHARS
                int nSrchLen = (rndm.Next() % 4) + 2;
                for (int j=0; j< nSrchLen; j++)
                    //CREATE SEARCH STRING
                    {
                    sb.Append(alpha[rndm.Next() % nAlphaLen]);
                    }
                string strSearch = sb.ToString();
                //DO THE SEARCH
                IEnumerable<Person> result = controller.Get(strSearch);
                if (result.Count() > 0)
                    {
                    foreach (var p in result)
                        {
                        string strFull = p.FirstName + " " + p.LastName;
                        Assert.Contains(strSearch, strFull, StringComparison.OrdinalIgnoreCase);
                        nFound += 1;
                        output.WriteLine("Search String: {0} Match: {1}", strSearch, strFull);
                        }
                    }
                else
                    output.WriteLine("No match for: {0}", strSearch);
                sb.Clear();
                }
            }
        }
    }

