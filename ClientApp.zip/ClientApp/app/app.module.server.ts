import { NgModule } from '@angular/core';
import { ServerModule } from '@angular/platform-server';
import { AppModuleShared } from './app.module.shared';
import { AppComponent } from './components/app/app.component';
import { HttpModule } from '@angular/http';


@NgModule({
    bootstrap: [AppComponent],
    imports: [
        ServerModule,
        HttpModule,
        AppModuleShared
    ]
})
export class AppModule {
}
