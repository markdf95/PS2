﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Component({
    selector: 'app-addperson',
    templateUrl: './addperson.component.html',
    styleUrls: ['./addperson.component.css']
})
/** addperson component*/

export class AddpersonComponent implements OnInit {

    /** addperson ctor */
    constructor(private _http: Http) { }

    /** Called by Angular after addperson component initialized */
    ngOnInit(): void { }
    //USE THIS TO CLEAR THE FILE INPUT CONTROL IF THE USER SELECTS WRONG FILE TYPE FOR IMAGE
    @ViewChild('FilInp')
    fileInp: any;

    public strEmpty: string = "";
    //WEB API SERVICE URL
    public strUrl: string = "http://localhost:20488/api/person";

    //DELETE A PERSON
    public DelPerson() {
        var strID: string = "";

        var inpVar = <HTMLInputElement>document.getElementById('strPersID');
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            strID = inpVar.value;
            //CHECK FOR NUMBER NOT STRING AND FOR CORRECT LENGTH
            var nID: number = Number(strID);
            //CHANGE BACK TO STRING AND IF IT WASN'T A NUMBER IT WILL BE = 'NaN'
            strID = nID.toString();
            if (strID.length > 0 && strID !== "NaN") {
                var hdrs = new Headers();
                hdrs.append('Content-Type', 'application/json');
                console.log(hdrs.toJSON());
                //TARGET WEBSITE MUST ACCEPT DELETE VERBS
                this._http.delete(this.strUrl + "?id=" + strID).map(res => res.json())
                    .subscribe(
                    data => { console.log(data); },
                    err => { console.log(err); }
                    );
                console.log("Posted data: " + strID);
                //FORCE PAGE UPDATE
                window.location.reload();

            }
            else alert("The person's ID number is required.");

        }
        else alert("Enter a valid ID number.");
    }

    public strFileName: string = "";
    public formData: FormData;
    
    onFileChange(event: any) {
        if (event.target.files.length > 0) {
            //SET UP TO POST IMAGE AFTER REST OF USER DATA IS POSTED
            //debugger;
            let fileList: FileList = event.target.files;
            if (fileList.length > 0) {
                let file: File = fileList[0];
                this.strFileName = file.name;
                 var strUpper  = this.strFileName.toUpperCase();
                 if (strUpper.endsWith('.JPG') || strUpper.endsWith('.BMP') || strUpper.endsWith('.PNG')) {
                    this.formData = new FormData();
                    this.formData.append('uploadFile', file, file.name);
                    //NEED CODE BELOW IF WE'RE POSTING ON FILE CHANGE
                    //let headers = new Headers()
                    ////headers.append('Content-Type', 'json');  
                    ////headers.append('Accept', 'application/json');  
                    //let options = new RequestOptions({ headers: headers });
                    //let apiUrl1 = this.strUrl; /*+"/api/ImgUpload";*/
                    //this._http.post(apiUrl1, formData, options)
                    //    .map(res => res.json())
                    //    .catch(error => Observable.throw(error))
                    //    .subscribe(
                    //    data => console.log('success'),
                    //    error => console.log(error)
                    //    )
                }
                else {
                    alert("Only supported file formats are .bmp, .jpg, .bmp");
                    if (document != null) {
                        var inpVar = <HTMLFormElement>document.getElementById("inForm");
                        if (inpVar != null) {
                            //RESET FILE INPUT CONTROL
                            this.fileInp.nativeElement.value = "";                            
                        }
                    }
                }
            }
            //window.location.reload();
        }
    }


    //ADD A PERSON
    public AddPerson() {
        //THESE ARE REQUIRED PARAMS FOR VALIDATION
        var strErr: string = this.strEmpty;
        var strFirst: string = this.strEmpty;
        var strLast: string = this.strEmpty;
        var strAddress: string = this.strEmpty;
        var strCity: string = this.strEmpty;
        var strState: string = this.strEmpty;
        var strZip: string = this.strEmpty;
        var strID: string = "0";
        //THESE HAVE DEFAULTS AND ARE OPTIONAL       
        var strAge: string = this.strEmpty;
        var strInterests: string = this.strEmpty;
        var strPicName: string = this.strEmpty;
        //var bImg: ByteString;
        let arrPerson: string[] = [strID, strFirst, strLast, strAge, strAddress, strCity, strState, strZip, strInterests, strPicName, strErr];

        //GET INPUT ELEMENTS AND PREP FOR INSERT
        this.ValidateAdd(arrPerson);
        
        if (arrPerson[10].length == 0) {
            //VALIDATED, CREATE NEW P CLASS BASED USING PERSON INTERFACE
            var pers: p = new p();
            pers.PersonID = 0;
            pers.FirstName = arrPerson[1];
            pers.LastName = arrPerson[2];
            pers.Age = Number(arrPerson[3]);
            pers.StreetAddress = arrPerson[4];
            pers.City = arrPerson[5];
            pers.State = arrPerson[6];
            pers.Zip = Number(arrPerson[7]);
            pers.Interests = arrPerson[8];
            pers.PicURL = arrPerson[9];
            pers.OpStatus = "Testing";

            var firstHeaders = new Headers();

            //SET CONTENT TYPE, THEN LIST ALL HEADERS         
            firstHeaders.append('Content-Type', 'application/json');
            console.log(firstHeaders.toJSON());
            const options = new RequestOptions({ headers: firstHeaders });
            //debugger;
            //REQUIRES CONTENT-TYPE HEADER, OTHERWISE ERR 415 'Unsupported media type.'
            this._http.post(this.strUrl, JSON.stringify(pers), options).map(res => res.json())
                .subscribe(
                data => { console.log(data); },
                err => { console.log(err); }
                );
            //SEE WHAT WAS POSTED
            console.log("Posted data: " + pers);
            
             //CLEAR THE HEADERS
            let headers = new Headers()
            options.headers = headers;
            //CHANGE THE ROUTE
            let apiURL = "http://localhost:20488/api/ImgUpload";
           //NOW POST THE IMAGE USING DIFFERENT ROUTE
            this._http.post(apiURL, this.formData, options)
                .map(res => res.json())
                .catch(error => Observable.throw(error))
                .subscribe(
                data => console.log('success'),
                error => console.log(error)
                )
            //FORCE PAGE UPDATE
            window.location.reload();
        }
        else {
            alert(arrPerson[10]);
        }
    }

    //VALIDATE THE REQUIRED FIELDS
    public ValidateAdd(arrPerson: string[]) {
        var inpVar = <HTMLInputElement>document.getElementById('strFirst');
        var bErr: boolean = false;

        //SET MISSING DATA ERR MSG
        arrPerson[10] = "Missing input.  Fields marked with a red asterisk are required."

        //VALIDATE REQUIRED FIELDS
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            arrPerson[1] = inpVar.value;
        }
        else {
            return arrPerson;
        }

        var inpVar = <HTMLInputElement>document.getElementById('strLast');
        //VALIDATE REQUIRED FIELDS
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            arrPerson[2] = inpVar.value;
        }
        else {
            return arrPerson;
        }

        var inpVar = <HTMLInputElement>document.getElementById('strStreet');
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            arrPerson[4] = inpVar.value;
        }
        else {
            return arrPerson;
        }

        var inpVar = <HTMLInputElement>document.getElementById('strCity');
        //VALIDATE REQUIRED FIELDS
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            arrPerson[5] = inpVar.value;
        }
        else {
            return arrPerson;

        }

        var inpVar = <HTMLInputElement>document.getElementById('strState');
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            arrPerson[6] = inpVar.value;
        }
        else {
            return arrPerson;
        }

        var inpVar = <HTMLInputElement>document.getElementById('strZip');
        //VALIDATE REQUIRED FIELDS
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            var strZip: string = inpVar.value;
            //CHECK FOR NUMBER NOT STRING AND FOR CORRECT LENGTH
            var nZip = Number(strZip);
            //CHANGE BACK TO STRING AND IF IT WASN'T A NUMBER IT WILL BE = 'NaN'
            strZip = nZip.toString();
            if (strZip.length != 5 || strZip === "NaN") {
                arrPerson[10] = "Zip codes must be a 5 digit number.";
                return arrPerson;
            }
            else arrPerson[7] = strZip;

        }
        else {
            return arrPerson;
        }
        //THIS FIELD ISN'T REQUIRED'
        var inpVar = <HTMLInputElement>document.getElementById('strInterests');
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            arrPerson[8] = inpVar.value;
        }
        else {
            arrPerson[8]="";
        }
        //VALIDATE AGE IS NUMBER
        var inpVar = <HTMLInputElement>document.getElementById('strAge');
        if ((inpVar !== null) && (inpVar.value.length > 0)) {
            var strAge: string = inpVar.value;
            var nAge = Number(strAge);
            if (nAge.toString() !== "NaN")
                arrPerson[3] = inpVar.value;
            else {
                arrPerson[10] = "Age must be a number.";  
                return arrPerson;
            }                         
        }
        else {
            arrPerson[3] = "";
        }

        //CLEAR ERR MSG
        arrPerson[10] = this.strEmpty;
        //RETURN VALIDATED DATA
        return arrPerson;
    }

}
class p implements Person {
    PersonID: number;
    FirstName: string;
    LastName: string;
    Age: number;
    StreetAddress: string;
    City: string;
    State: string;
    Zip: number;
    Interests: string;
    PicURL: string;
    OpStatus: string;
}
interface Person {
    PersonID: number;
    FirstName: string;
    LastName: string;
    Age: number;
    StreetAddress: string;
    City: string;
    State: string;
    Zip: number;
    Interests: string;
    //public byte[] PicURL;// { get; set; } = "No Picture provided";
    PicURL: string;
    OpStatus: string;
}