﻿import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';

import 'rxjs/add/operator/map';


@Component({
    selector: 'app-person',
    templateUrl: './person.component.html',
    styleUrls: ['./person.component.css']

})
/** person component*/
export class PersonComponent implements OnInit {
    public strLoading: string = "";
    /** person ctor */
    constructor(private _http: Http) {
        
        this.getRecs();
    }

    /** Called by Angular after person component initialized */
    ngOnInit(): void { }

    public persons: any[];
    public svrWebAPI: string = "http://localhost:20488/api/person?search=";

    //GETS CALLED BY CONSTRUCTOR ON INTIAL LOAD AND WHEN SEARCHING
    public getRecs(strURL: string = "") {
        var strAPI = strURL;

        this._http.get(this.svrWebAPI + strAPI)
            .subscribe(result => {
                this.persons = result.json();
                console.log(this.persons)
            });

    }

    public findPersons() {
        var strSrch = "";
        if (document.getElementById('srchStr') !== null) {
            var s = <HTMLInputElement>document.getElementById('srchStr');
            strSrch = s.value
            console.log(strSrch);
        }
        this.getRecs(strSrch);
    }

}

