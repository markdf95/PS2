import MagicString from './MagicString.js';

export default MagicString;
export { default as Bundle } from './Bundle.js';
