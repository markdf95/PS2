import { PrebootOptions, Window, Element } from '../src/preboot_interfaces';
export declare function getMockWindow(): Window;
export declare function getMockOptions(): PrebootOptions;
export declare function getMockElement(): Element;
export declare function addParent(anode: any): void;
