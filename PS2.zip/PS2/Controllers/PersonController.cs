﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using PS2.Models;
using System.Web.Http.Cors;
using System.DrawingCore;
using System.IO;
using Microsoft.EntityFrameworkCore;
using System.Collections.Specialized;

namespace PS2.Controllers
    {
    [Produces("application/json")]
    [Route("api/Person")]
    public class PersonController : Controller
        {
        private readonly PS2Context _context;

        public PersonController(PS2Context context)
            {
            _context = context;

            if (_context.Persons.Count() == 0)
                {
                //SEED THE SERVICE WITH 5 PEOPLE
                string strDir = Directory.GetCurrentDirectory() + "\\Images\\";
                var pimage1 = Image.FromFile(strDir + "pic1.jpg");
                byte[] imgArr1 = imageToByteArray(pimage1);
                var pimage2 = Image.FromFile(strDir + "pic2.jpg");
                byte[] imgArr2 = imageToByteArray(pimage2);
                var pimage3 = Image.FromFile(strDir + "pic3.jpg");
                byte[] imgArr3 = imageToByteArray(pimage3);
                var pimage4 = Image.FromFile(strDir + "pic4.jpg");
                byte[] imgArr4 = imageToByteArray(pimage4);
                var pimage5 = Image.FromFile(strDir + "pic5.jpg");
                byte[] imgArr5 = imageToByteArray(pimage5);

                _context.Persons.AddRange(new Person { FirstName = "Mark", LastName = "Abbey", Age = 55, City = "Fillmore", StreetAddress = "160 E Center St", Interests = "ATVs, guitar, fishing", PicName = strDir + "pic1.jpg", Pic = imgArr1, State = "UT", Zip = 84631 },
                    new Person { FirstName = "Jason", LastName = "Bellows", Age = 23, City = "Remote", StreetAddress = "1630 Main St", Interests = "hiking, trumpet, football", PicName = strDir + "pic2.jpg", Pic = imgArr2, State = "WY", Zip = 33821 },
                    new Person { FirstName = "Maria Elena", LastName = "Eritrea", Age = 44, City = "Turkey", StreetAddress = "32 West Oak Boulevard", Interests = "cooking, bicycling, basketball", PicName = strDir + "pic3.jpg", Pic = imgArr3, State = "AK", Zip = 98722 },
                    new Person { FirstName = "Trevor", LastName = "Evinrude", Age = 52, City = "Walnut", StreetAddress = "431 First Ave.", Interests = "boating, gardening", State = "TX", PicName = strDir + "pic4.jpg", Pic = imgArr4, Zip = 22562 },
                    new Person { FirstName = "Bill", LastName = "O'Reilly", Age = 52, City = "Amityville", StreetAddress = "431 First Ave.", Interests = "boating, gardening", State = "TX", PicName = strDir + "pic5.jpg", Pic = imgArr5, Zip = 22562 });

                _context.SaveChanges();
                }
            }
        public byte[] imageToByteArray(Image imageIn)
            {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.DrawingCore.Imaging.ImageFormat.Jpeg);
            return ms.ToArray();
            }

        // GET RECORDS      
        [HttpGet(Name = "GetPerson")]
        public IEnumerable<Person> Get(string Search)
            {
            try
                {
                //CAN SIMULATE LONG LOAD TIME
                //System.Threading.Thread.Sleep(5000);
                if (string.Equals(Search, "all", StringComparison.OrdinalIgnoreCase) || Search is null)
                    {
                    //"all" OR NO PARAM SPECIFIED, PROVIDE ALL
                    return _context.Persons.ToList();
                    }
                else
                    {
                    //MATCH FIRST/LAST NAME CASE INSENSITIVE
                    var PersonSearch = (from p in _context.Persons
                                        where (p.FirstName.IndexOf(Search, StringComparison.OrdinalIgnoreCase) > -1)
                                        || (p.LastName.IndexOf(Search, StringComparison.OrdinalIgnoreCase) > -1)
                                        select p).OrderBy(p => p.PersonID).ToList();
                    return PersonSearch;
                    }
                }
            catch (Exception ex)
                {
                //SET ERROR MSG TO PREVENT UGLY STACK TRACE, ETC.  USERS CAN CHECK OpStatus 
                //AFTER A CALL TO ENSURE SUCCESS
                List<Person> p = new List<Person>
                    {
                    new Person()
                    };
                //DEFAULT STATUS IS "Success"
                p[0].OpStatus = ex.Message;
                return p;
                }


            }
        
        [HttpPost]
        [EnableCors(origins: "http://localhost:59684/", headers: "*", methods: "*")]
        public IActionResult Create([FromBody] Person pers)
            {
            try
                {
                if (pers == null)
                    {
                    return BadRequest("Payload was null");
                    }
                Console.WriteLine("Posted:" + pers);
                _context.Persons.Add(pers);
                _context.SaveChanges();
                return Ok();
                }
            catch (System.Exception ex)
                {
                return BadRequest(ex.Message);
                }
            }


        [HttpDelete]
        [EnableCors(origins: "http://localhost:59684/", headers: "*", methods: "*")]
        public IActionResult Delete()
            {
            //GET ID FROM QUERY STRING
            string strQ = Request.QueryString.Value;
            if (!string.IsNullOrEmpty(strQ))
                {
                // Parse the query string variables into a NameValueCollection.
                NameValueCollection qscoll = System.Web.HttpUtility.ParseQueryString(strQ);
                var pers = _context.Persons.Where(s => s.PersonID == Convert.ToInt64(qscoll["id"]))
                    .FirstOrDefault();
                if (pers != null)
                    {
                    _context.Entry(pers).State = EntityState.Deleted;
                    _context.SaveChanges();
                    }
                }
            
            return Ok();
            }

        }

    }
