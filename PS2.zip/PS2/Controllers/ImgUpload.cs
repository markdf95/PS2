﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web.Http.Cors;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PS2.Models;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PS2.Controllers
    {
    [Route("api/ImgUpload")]
    public class ImgUpload : Controller
        {
        private IHostingEnvironment _env;
        private readonly PS2Context _context;
        //CONSTRUCTOR TO GET PATH FUNCTIONS
        public ImgUpload(IHostingEnvironment env, PS2Context context)
            {
            _env = env;
            _context = context;
            }
        // GET: api/values
        [HttpGet]
        public IEnumerable<string> Get()
            {
            return new string[] { "value1", "value2" };
            }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
            {
            return "value";
            }

        // POST api/ImgUpload
        [HttpPost]
        [EnableCors(origins: "http://localhost:59684/", headers: "*", methods: "*")]
        public HttpResponseMessage UploadJsonFile()
            {
            HttpResponseMessage response = null;
            try
                {
                //HAD TO REFACTOR FOR ASP.NET CORE
                response = new HttpResponseMessage();
                //var httpRequest = HttpContext.Current.Request;
                var form = HttpContext.Request.Form;
                IFormFile postedFile = null;
                //if (httpRequest.Files.Count > 0)
                if (form.Files.Count > 0)
                    {
                    //foreach (string file in httpRequest.Files)
                    //var postedFile = httpRequest.Files[file];
                    //var filePath = HttpContext.Current.Server.MapPath("~/UploadFile/" + postedFile.FileName);
                    //postedFile.SaveAs(filePath);
                    for (int i = 0; i < form.Files.Count; i++)
                        {
                        postedFile = form.Files[i];
                        var filePath = _env.ContentRootPath;
                        var appfilePath = System.IO.Path.Combine(filePath, "Images\\" + postedFile.FileName);
                        using (var fileStream = new FileStream(appfilePath, FileMode.Create))
                            {
                            postedFile.CopyToAsync(fileStream);
                            }
                        }
                    }
                //ASSOCIATE THIS IMAGE WITH LAST INSERTED PERSON - WOULD CHANGE DURING PRODUCTION TO PREVENT
                //PIC BEING ASSOCIATED WITH WRONG RECORD
                long lngMaxID = _context.Persons.Max(p => p.PersonID);
                //WRITE BYTE ARRAY
                using (var ms = new MemoryStream())
                    {
                    postedFile.CopyTo(ms);
                    var fileBytes = ms.ToArray();
                    //LINQ FOR UPDATE
                    var qry = from Person in _context.Persons where Person.PersonID == lngMaxID select Person;
                    var item = qry.Single();
                    item.Pic = fileBytes;
                    item.PicName = postedFile.FileName;
                    _context.SaveChanges();

                    }

                return response;
                }
            catch (System.Exception ex)
                {
                if (response == null)
                    response = new HttpResponseMessage();

                response.StatusCode = System.Net.HttpStatusCode.BadRequest;
                response.ReasonPhrase = ex.Message;
                return response;
                }
            finally
                {
                response.Dispose();
                }
            }

        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
            {
            }


        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
            {
            }
        }
    }









//public void Post([FromBody]string value)
//{
//}


//public async Task<IActionResult> Post(List<IFormFile> files)
//    {
//    long size = 1;// files.Sum(f => f.Length);

//    // full path to file in temp location
//    var filePath = Path.GetTempFileName();

//    foreach (var formFile in files)
//        {
//        if (formFile.Length > 0)
//            {
//            using (var stream = new FileStream(filePath, FileMode.Create))
//                {
//                await formFile.CopyToAsync(stream);
//                }
//            }
//        }

// process uploaded files
//    // Don't rely on or trust the FileName property without validation.

//    return Ok(new { count = files.Count, size, filePath });
//    }





//public interface IFormFile
//    {
//    string ContentType { get; }
//    string ContentDisposition { get; }
//    IHeaderDictionary Headers { get; }
//    long Length { get; }
//    string Name { get; }
//    string FileName { get; }
//    Stream OpenReadStream();
//    void CopyTo(Stream target);
//    Task CopyToAsync(Stream target, CancellationToken cancellationToken = default(CancellationToken));
//    }
