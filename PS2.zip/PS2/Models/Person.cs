﻿namespace PS2.Models
    {
    public class Person
        {
        public long PersonID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Zip { get; set; }
        public string Interests { get; set; } = "No interests....boring!";
        //public byte[] PicURL;// { get; set; } = "No Picture provided";
        public string PicName { get; set; } = "No Picture provided";
        public byte[] Pic { get; set; }
        public string OpStatus = "Success";
    }
}
