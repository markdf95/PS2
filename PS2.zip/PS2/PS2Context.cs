﻿using Microsoft.EntityFrameworkCore;

namespace PS2.Models
    {
    public class PS2Context : DbContext
        {
        public PS2Context(DbContextOptions<PS2Context> options)
            : base(options)
            {
            }

        public DbSet<Person> Persons { get; set; }
        }
    }
